---
document: ARCHITECTURE.md
generated: 2026-06-17
client_level: developer
---

# 系统架构

## 架构总览

```mermaid
graph LR
    A[用户浏览器] -->|访问| B[Cloudflare Pages]
    B -->|静态 HTML| C[展厅 index.html]
    C -->|iframe 加载| D[pages/*.html]
    C -->|img src| E[assets/screenshots/*.png]
    F[开发者本地] -->|wrangler deploy| B
    G[AI 模型 + Skills] -->|生成 HTML| H[03-产出/]
    H -->|复制| D
    H -->|截图脚本| E
```

本项目是**完全静态**的 Web 应用，无后端服务、无数据库、无运行时 AI 调用。

**数据流向**：
1. AI 模型（Kimi/Gemini/DeepSeek 等）在 design skill 驱动下生成 HTML 页面 → 存入 `03-产出/` 目录
2. HTML 文件复制到 `05-报告/展厅/pages/`，运行截图脚本生成缩略图 → 存入 `assets/screenshots/`
3. 开发者通过 Wrangler CLI 将展厅目录部署到 Cloudflare Pages
4. 用户通过 `https://frontend-design-skills-showcase.pages.dev` 访问展厅，按模型/场景/技能筛选浏览

## 目录结构

```
01-前端设计技能测评/
├── 01-技能/                          # 14 款 design skill 的定义文件
│   ├── skills来源与安装地址.md       # 安装命令参考
│   ├── 版本锁定.json                 # skill 版本哈希锁定
│   └── 已安装技能/skills/           # 14 个 skill 的 SKILL.md
├── 02-输入/产品说明文档/             # 3 个测试场景的产品需求文档
│   ├── 星空航空公司官网说明文档.md
│   ├── 电动车充电桩小程序产品说明文档.md
│   └── 共享两轮城市运营管理后台说明文档.md
├── 03-产出/                          # 各模型的 HTML 产出（核心数据）
│   ├── kimi/                         # Kimi 2.5 (45 页)
│   ├── mimoV2omni/                   # Mimo V2 Omni (37 页)
│   ├── glm/                          # GLM (40 页)
│   ├── gemini3/                      # Gemini 3 (42 页)
│   ├── mimoV2.5/                     # Mimo V2.5 (42 页)
│   ├── minimaxM3/                    # MiniMax M3 (42 页)
│   ├── deepseek/                     # DeepSeek V4 (42 页)
│   ├── kimi-k2.6/                    # Kimi K2.6 (42 页)
│   └── qwen3.7-plus/                # Qwen 3.7 Plus (42 页)
├── 05-报告/展厅/                     # 展厅静态站点（部署单元）
│   ├── index.html                    # 主页面，含模型/场景/技能筛选逻辑
│   ├── view.html                     # 单页预览器
│   ├── pages/                        # 388 个 HTML 副本
│   └── assets/screenshots/           # 388 张缩略图截图
├── project-handoff/                  # 本交接文档
├── ScreenShot/                       # 开发过程中的验证截图
└── TempScr/                          # 临时脚本
```

## 技术选型与路线

**为什么用纯静态 HTML 而不是 React/Vue？**
本项目的核心产出是 AI 模型生成的 HTML 页面，这些页面本身就是静态文件。展厅只需要一个 index.html 来组织和展示这些文件，无需构建工具或框架。Tailwind CSS 通过 CDN 引入，零配置。

**为什么用 Cloudflare Pages？**
- 免费额度充足（纯静态站点）
- 全球 CDN 加速
- Wrangler CLI 支持一键部署
- 无需服务器运维

## 外部资源依赖

| 类型 | 资源 | 说明 |
|---|---|---|
| CDN | `https://cdn.tailwindcss.com` | Tailwind CSS 运行时，展厅 index.html 使用 |
| CDN | `https://cdn.jsdelivr.net/npm/@iconify-json/*` | 各 HTML 页面中使用的图标库，按需加载 |
| CDN | `https://fonts.googleapis.com` | Google Fonts，各 HTML 页面字体 |

所有 CDN 资源为运行时必需，国内访问可能较慢但不影响功能。如需加速可替换为国内 CDN 镜像。

## AI 工具链

**本次交接文档生成过程中使用的工具**:
- **Skills**: `project-handoff`（交接文档生成）
- **MCP Servers**: 无
- **Agent 类型**: 无

## 开发环境痕迹

**原开发平台**: Windows 11 Enterprise LTSC 2024

**AI 辅助工具**: Claude Code（用于生成页面、截图、部署等）

**接手方要求**: 任何支持 Python 或 Node.js 的操作系统即可运行本地服务器和截图脚本。部署需要 Cloudflare 账号和 Wrangler CLI。
